package com.company;


public class samochod {

    public static void main(String[] args) {
        {
            System.out.println("wrum");

            int przebieg = 69;

            System.out.println("auto przejechało " + przebieg + " km");

            System.out.println("Auto skrecilo w prawo");
        }

    }
}